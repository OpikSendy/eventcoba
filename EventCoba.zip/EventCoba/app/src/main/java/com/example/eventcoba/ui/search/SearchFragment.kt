package com.example.eventcoba.ui.search

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.eventcoba.data.repository.EventRepository
import com.example.eventcoba.databinding.FragmentSearchBinding
import com.example.eventcoba.ui.adapter.EventAdapter
import com.example.eventcoba.ui.utils.Resource
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SearchFragment : Fragment() {

    private lateinit var binding: FragmentSearchBinding
    private lateinit var searchViewModel: SearchViewModel
    private lateinit var eventAdapter: EventAdapter

    // Job untuk debounce
    private var searchJob: Job? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repository = EventRepository() // Assuming the repository is correctly set up
        searchViewModel = ViewModelProvider(this, SearchViewModelFactory(repository))[SearchViewModel::class.java]

        eventAdapter = EventAdapter()
        binding.recyclerView.apply {
            adapter = eventAdapter
            layoutManager = LinearLayoutManager(context)
        }

        // Pencarian real-time dengan debounce
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let {
                    performSearch(it)  // Jika pengguna men-submit langsung
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                searchJob?.cancel() // Membatalkan job sebelumnya jika ada
                searchJob = MainScope().launch {
                    delay(500L) // Menunggu 500ms sebelum memulai pencarian (debounce)
                    newText?.let {
                        if (it.isNotEmpty()) {
                            performSearch(it)
                        } else {
                            eventAdapter.submitList(emptyList())
                        }
                    }
                }
                return true
            }
        })

        searchViewModel.searchResults.observe(viewLifecycleOwner) { resource ->
            when (resource) {
                is Resource.Success -> {
                    eventAdapter.submitList(resource.data)
                    binding.progressBar.visibility = View.GONE
                }
                is Resource.Error -> {
                    Toast.makeText(context, "Error: ${resource.message}", Toast.LENGTH_SHORT).show()
                    binding.progressBar.visibility = View.GONE
                }
                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun performSearch(query: String) {
        searchViewModel.searchEvents(query)
    }
}

