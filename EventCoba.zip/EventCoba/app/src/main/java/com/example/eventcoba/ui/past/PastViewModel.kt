package com.example.eventcoba.ui.past

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventcoba.data.model.ListEventsItem
import com.example.eventcoba.data.repository.EventRepository
import com.example.eventcoba.ui.utils.Resource
import kotlinx.coroutines.launch

class PastViewModel : ViewModel() {
    private val repository = EventRepository()

    private val _events = MutableLiveData<Resource<List<ListEventsItem>>>()
    val events: LiveData<Resource<List<ListEventsItem>>> = _events

    init {
        fetchEvents()
    }

    private fun fetchEvents() {
        viewModelScope.launch {
            _events.value = Resource.Loading()
            val result = repository.getPastEvents()
            _events.value = result
        }
    }
}