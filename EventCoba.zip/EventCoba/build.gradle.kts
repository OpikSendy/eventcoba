// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false

}

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath(libs.gradle) // Ganti dengan versi terbaru jika diperlukan
        classpath(libs.kotlin.gradle.plugin) // Ganti dengan versi Kotlin terbaru
        classpath(libs.navigation.safe.args.gradle.plugin) // Ganti dengan versi terbaru
    }
}